"""
SymPy statistics module
"""

from distributions import Normal, Uniform
